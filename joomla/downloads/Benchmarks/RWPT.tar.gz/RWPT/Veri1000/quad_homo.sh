echo --------------------------------------------------------------
echo Random Walk Particle Tracking Benchmarks
echo Stand: 15.01.2006
echo last modified PCH
echo --------------------------------------------------------------
echo Random Walk Particle Tracking Process - quad_homo
../../../rf4-icc quad_homo > quad_homo.txt
echo
echo Delete files
echo rm -f *.rfe
echo rm -f *.rfo
rm -f *.bak
echo rm -f *.N00
rm -f *.sv1
rm -f *.sv2
rm -f pstprz.rf
