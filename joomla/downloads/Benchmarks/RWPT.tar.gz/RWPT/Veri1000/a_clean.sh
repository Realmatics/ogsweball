echo Delete files
rm *.rfe
rm *.rfo
rm *.bak
rm *.N0*
rm *.sv1
rm *.sv2
rm pstprz.rf
rm *.plt
rm *.exe
rm *.phy
rm *.dat
rm *.glp
rm *.txt
rm *.rfg
rm *.tec
rm 1*.pct 2*.pct 3*.pct 4*.pct 5*.pct 6*.pct 7*.pct 8*.pct 9*.pct
